inputDir = getDirectory("Choose a folder");

// Create output directory
outputDir = substring(inputDir, 0, lengthOf(inputDir) - 1) + "_counted\\";
if (!File.exists(outputDir)) {
    File.makeDirectory(outputDir);
}

// Get list of image files
list = getFileList(inputDir);

for (i = 0; i < list.length; i++) {
    filePath = inputDir + list[i];

    try {
        // Attempt to run the Auto Label command
        run("Auto Label", "arg=" + filePath);
    } catch (error) {
        // Handle any errors that occur during the run command
        console.error("Error processing file " + filePath + ": " + error.message);
    }

    // Close the image
    while (nImages > 0) {
         close();
    }
}

print("Batch processing complete! Images saved to: " + outputDir);
